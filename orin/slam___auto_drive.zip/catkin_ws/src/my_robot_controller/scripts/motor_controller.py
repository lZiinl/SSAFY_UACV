#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from adafruit_motor import motor
from adafruit_pca9685 import PCA9685
from adafruit_servokit import ServoKit
import board
import busio

class RobotController:
    def __init__(self):
        self.i2c = busio.I2C(board.SCL, board.SDA)
        self.pca = PCA9685(self.i2c)
        self.pca.frequency = 60
        self.motor_hat = PWMThrottleHat(self.pca, channel=0)
        self.kit = ServoKit(channels=16, i2c=self.i2c, address=0x60)
        
        rospy.init_node('robot_controller')
        rospy.Subscriber('/cmd_vel', Twist, self.cmd_vel_callback)
        rospy.spin()

    def cmd_vel_callback(self, msg):
        linear_speed = msg.linear.x
        angular_speed = msg.angular.z

        # 설정: 전진 및 후진을 위한 DC 모터 제어
        if linear_speed > 0:
            self.motor_hat.set_throttle(1)
        elif linear_speed < 0:
            self.motor_hat.set_throttle(-1)
        else:
            self.motor_hat.set_throttle(0)

        # 설정: 회전을 위한 서보 모터 제어
        if angular_speed > 0:
            self.kit.servo[0].angle = 45  # 오른쪽으로 회전
        elif angular_speed < 0:
            self.kit.servo[0].angle = 135  # 왼쪽으로 회전
        else:
            self.kit.servo[0].angle = 90  # 중앙 위치

class PWMThrottleHat:
    def __init__(self, pwm, channel):
        self.pwm = pwm
        self.channel = channel
        self.pwm.frequency = 60

    def set_throttle(self, throttle):
        pulse = int(0xFFFF * abs(throttle))
        if throttle > 0:
            self.pwm.channels[self.channel + 5].duty_cycle = pulse
            self.pwm.channels[self.channel + 4].duty_cycle = 0xFFFF
            self.pwm.channels[self.channel + 3].duty_cycle = 0
        elif throttle < 0:
            self.pwm.channels[self.channel + 5].duty_cycle = pulse
            self.pwm.channels[self.channel + 4].duty_cycle = 0
            self.pwm.channels[self.channel + 3].duty_cycle = 0xFFFF
        else:
            self.pwm.channels[self.channel + 5].duty_cycle = 0
            self.pwm.channels[self.channel + 4].duty_cycle = 0
            self.pwm.channels[self.channel + 3].duty_cycle = 0

if __name__ == '__main__':
    try:
        robot_controller = RobotController()
    except rospy.ROSInterruptException:
        pass
    finally:
        rospy.loginfo("Shutting down robot controller node.")

