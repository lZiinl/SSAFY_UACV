#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, LaserScan
from geometry_msgs.msg import PoseWithCovarianceStamped, TwistWithCovarianceStamped
import math
import tf
from geometry_msgs.msg import Quaternion

# 가속도 데이터와 스캔 데이터를 저장하기 위한 글로벌 변수
accel_data = None
scan_data = None

def imu_callback(data):
    global accel_data
    accel_data = data

def scan_callback(data):
    global scan_data
    scan_data = data

def calculate_position():
    x, y, z = 0.0, 0.0, 0.0
    # 가속도 데이터를 사용하여 위치 업데이트
    if accel_data:
        accel_x = accel_data.linear_acceleration.x
        accel_y = accel_data.linear_acceleration.y
        # 가속도를 위치 변화로 가정 (단순화된 예)
        x += accel_x * 0.5 * 0.1**2  # Δt^2
        y += accel_y * 0.5 * 0.1**2  # Δt^2
    # 스캔 데이터를 사용하여 추가적 위치 보정
    if scan_data:
        # 스캔 데이터 중 최소 거리 측정 (단순화된 예)
        min_distance = min(scan_data.ranges)
        # LiDAR 데이터를 기반으로 위치 보정
        z = min_distance
    return x, y, z

def odometry_publisher():
    rospy.init_node('odometry_fusion_publisher', anonymous=True)

    rospy.Subscriber('/imu/data', Imu, imu_callback)
    rospy.Subscriber('/scan', LaserScan, scan_callback)

    odom_pub = rospy.Publisher('odom', Odometry, queue_size=50)
    rate = rospy.Rate(10)  # 10Hz

    while not rospy.is_shutdown():
        x, y, z = calculate_position()
        odom_msg = Odometry()
        odom_msg.header.stamp = rospy.Time.now()
        odom_msg.header.frame_id = "odom"
        odom_msg.child_frame_id = "base_link"
        
        odom_msg.pose.pose.position.x = x
        odom_msg.pose.pose.position.y = y
        odom_msg.pose.pose.position.z = z
        quaternion = tf.transformations.quaternion_from_euler(0, 0, 0)
        odom_msg.pose.pose.orientation = Quaternion(*quaternion)

        odom_msg.twist.twist.linear.x = 0.1  # 이동 속도
        odom_msg.twist.twist.angular.z = 0.1  # 회전 속도

        odom_pub.publish(odom_msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        odometry_publisher()
    except rospy.ROSInterruptException:
        pass

