#!/usr/bin/env python3

import rospy
import tf
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry


class TransformBroadcaster:
    def __init__(self):
        rospy.init_node('tf_broadcaster')
        
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.handle_odom)
        self.br = tf.TransformBroadcaster()
        self.rate = rospy.Rate(10)

    def handle_odom(self, msg):
        # Broadcast the dynamic transform from 'odom' to 'base_link'
        self.br.sendTransform(
            (msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z),
            (msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w),
            msg.header.stamp,
            "base_link",
            "odom"
        )

    def broadcast_static_transforms(self, current_time):

        # map to odom (This should ideally be provided by an external localization node like AMCL)
        self.br.sendTransform(
            (0.0, 0.0, 0.0),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "odom",
            "map"
        )

        # imu_link to base_link transform
        #self.br.sendTransform(
        #    (0.1, 0.0, 0.1),  # IMU의 base_link에 대한 위치
        #    tf.transformations.quaternion_from_euler(0, 0, 0),  # IMU의 base_link에 대한 방향
        #    current_time,
        #    "base_link",
        #    "imu_link"
        #)

        # map to base link
        #self.br.sendTransform(
        #    (0.0, 0.0, 0.0),
        #    tf.transformations.quaternion_from_euler(0, 0, 0),
        #    current_time,
        #    "base_link",
        #    "map"
        #)

        # Base Link to Front Left Steering Link
        self.br.sendTransform(
            (0.08, 0.075, 0.0325),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "front_left_steering_link",
            "base_link"
        )

        # Base Link to Front Right Steering Link
        self.br.sendTransform(
            (0.08, -0.075, 0.0325),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "front_right_steering_link",
            "base_link"
        )

	# Front Left Steering Link to Front Right Wheel
        self.br.sendTransform(
            (0.0, 0.0, 0.0),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "front_left_wheel",
            "front_left_steering_link"
        )

        # Front Right Steering Link to Front Right Wheel
        self.br.sendTransform(
            (0.0, 0.0, 0.0),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "front_right_wheel",
            "front_right_steering_link"
        )

        # Base Link to Rear Left Wheel
        self.br.sendTransform(
            (-0.17, 0.075, 0.0325),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "rear_left_wheel",
            "base_link"
        )

        # Base Link to Rear Right Wheel
        self.br.sendTransform(
            (-0.17, -0.075, 0.0325),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "rear_right_wheel",
            "base_link"
        )

        # Base Link to RPLidar
        self.br.sendTransform(
            (0.0, 0.0, 0.175),
            tf.transformations.quaternion_from_euler(0, 0, 0),
            current_time,
            "rplidar_link",
            "base_link"
        )

    def run(self):
        while not rospy.is_shutdown():
            current_time = rospy.Time.now()
            self.broadcast_static_transforms(current_time)
            self.rate.sleep()

if __name__ == '__main__':
    broadcaster = TransformBroadcaster()
    broadcaster.run()

