#!/usr/bin/env python3

import rospy
import tf
from nav_msgs.msg import Odometry

class OdomToTF:
    def __init__(self):
        rospy.init_node('odom_to_tf_broadcaster')
        self.odom_sub = rospy.Subscriber('/odom', Odometry, self.handle_odom)
        self.br = tf.TransformBroadcaster()
        self.rate = rospy.Rate(10)  # 10 Hz

    def handle_odom(self, msg):
        # 추출한 오도메트리 데이터를 이용하여 tf 변환 발행
        self.br.sendTransform(
            (msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z),
            (msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w),
            msg.header.stamp,
            "base_link",
            "odom"
        )

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    odom_tf_broadcaster = OdomToTF()
    odom_tf_broadcaster.run()
