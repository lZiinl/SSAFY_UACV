#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import serial
import rospy
from sensor_msgs.msg import Imu
import math

UART_PORT = '/dev/ttyTHS0'  # 실제 포트명으로 변경 필요
BAUD_RATE = 115200

def parse_imu_data(data):
    parts = data.split(': ', 1)
    if len(parts) != 2:
        rospy.logwarn("Unexpected data format: {}".format(data))
        return None

    data_type, data_values = parts
    values = data_values.split(', ')

    imu_msg = Imu()
    imu_msg.header.stamp = rospy.Time.now()
    imu_msg.header.frame_id = "imu_link"

    try:
        if "Accelerometer" in data_type or "Gyroscope" in data_type:
            # '='을 기준으로 각 축의 값을 분리
            values = [v.split('=') for v in values if '=' in v]
            # 데이터가 X, Y, Z 모두 존재하는지 확인
            if len(values) != 3:
                rospy.logwarn(f"Not enough values to unpack for {data_type}: {values}")
                return None
            # 값 추출 및 변환
            x, y, z = [float(value[1]) for value in values]
            if "Accelerometer" in data_type:
                imu_msg.linear_acceleration.x = x
                imu_msg.linear_acceleration.y = y
                imu_msg.linear_acceleration.z = z
            elif "Gyroscope" in data_type:
                imu_msg.angular_velocity.x = x
                imu_msg.angular_velocity.y = y
                imu_msg.angular_velocity.z = z
        else:
            rospy.logwarn("Unrecognized data type: {}".format(data_type))
            return None

    except ValueError as e:
        rospy.logerr("Error parsing IMU data: {}".format(e))
        return None

    return imu_msg


def read_sensor_data():
    try:     
        ser = serial.Serial(UART_PORT, BAUD_RATE, timeout=1)
        rospy.loginfo("Imu reader initialized on {}".format(UART_PORT))
    except serial.SerialException as e:
        rospy.logerr("Unable to open serial port {}: {}".format(UART_PORT, e))
        return

    pub = rospy.Publisher('/imu', Imu, queue_size=10)
    rospy.init_node('imu_reader_node', anonymous=True)

    while not rospy.is_shutdown():
        try:
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8', errors='replace').rstrip()
                imu_msg = parse_imu_data(line)
                if imu_msg:
                    pub.publish(imu_msg)
        except UnicodeDecodeError as e:
            rospy.logwarn(f"Decoding error encountered: {e}")
        except serial.SerialException as e:
            rospy.logerr(f"Serial communication error: {e}")
            break

    ser.close()

if __name__ == "__main__":
    read_sensor_data()

