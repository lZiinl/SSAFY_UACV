#!/usr/bin/env python3
import rospy
import serial
from sensor_msgs.msg import Imu

# 수신 측의 UART 포트 설정
UART_PORT = '/dev/ttyTHS0'  # 실제 포트명으로 변경 필요
BAUD_RATE = 115200

def imu_publisher():
    # 시리얼 포트 연결
    ser = serial.Serial(UART_PORT, BAUD_RATE, timeout=1)
    rospy.loginfo(f"Listening for messages on {UART_PORT}")

    # IMU 데이터 토픽 발행자 설정
    pub = rospy.Publisher('imu_data', Imu, queue_size=10)
    rospy.init_node('imu_publisher_node', anonymous=True)
    rate = rospy.Rate(10)  # 10Hz

    while not rospy.is_shutdown():
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8').rstrip()
            imu_data = parse_imu_data(line)
            if imu_data:
                pub.publish(imu_data)
        rate.sleep()

def parse_imu_data(data_line):
    imu_msg = Imu()
    try:
        # 데이터 파싱 로직
        parts = data_line.split(',')
        for part in parts:
            key_value = part.split(':')
            if len(key_value) == 2:
                key, value = key_value
                if 'Heading' in key:
                    # 보정 필요
                    pass
                elif 'Accelerometer' in key:
                    accel_values = value.strip().split(' ')
                    imu_msg.linear_acceleration.x = float(accel_values[0].split('=')[1])
                    imu_msg.linear_acceleration.y = float(accel_values[1].split('=')[1])
                    imu_msg.linear_acceleration.z = float(accel_values[2].split('=')[1])
                elif 'Gyroscope' in key:
                    gyro_values = value.strip().split(' ')
                    imu_msg.angular_velocity.x = float(gyro_values[0].split('=')[1])
                    imu_msg.angular_velocity.y = float(gyro_values[1].split('=')[1])
                    imu_msg.angular_velocity.z = float(gyro_values[2].split('=')[1])
    except Exception as e:
        rospy.logerr(f"Failed to parse IMU data: {e}")
    return imu_msg

if __name__ == '__main__':
    try:
        imu_publisher()
    except rospy.ROSInterruptException:
        pass
    finally:
        rospy.loginfo("Shutting down IMU publisher node.")

