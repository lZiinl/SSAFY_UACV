#!/usr/bin/env python

import rospy
import tf
from tf import TransformBroadcaster

def handle_lidar_pose():
    br = TransformBroadcaster()
    rate = rospy.Rate(10.0)
    while not rospy.is_shutdown():
        br.sendTransform((0.0, 0.0, 0.1),
                         tf.transformations.quaternion_from_euler(0, 0, 0), 
                         rospy.Time.now(),
                         "base_link",
                         "laser")  
        rate.sleep()

if __name__ == '__main__':
    rospy.init_node('lidar_tf_broadcaster')
    handle_lidar_pose()
    rospy.spin()

